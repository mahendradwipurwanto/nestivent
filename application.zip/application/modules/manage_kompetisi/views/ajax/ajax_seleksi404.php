<div class="text-center mt-lg-5 my-auto mx-lg-10 mb-5">
	<img class="avatar avatar-xxl" src="<?= base_url();?>assets/backend/svg/illustrations/sorry.svg" alt="Image Description">
	<p class="card-text">Belum ada data.</p>
</div>
<br>