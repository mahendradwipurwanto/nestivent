<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_zoom extends CI_Model {
	function __construct(){
		parent::__construct();
	}
}
