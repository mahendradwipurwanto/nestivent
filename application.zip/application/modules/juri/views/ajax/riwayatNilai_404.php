<div class="card-header">
	<h5 class="card-header-title">Karya Tim</h5>
</div>
<div class="card-body">
	<div class="text-center mt-lg-5 my-auto mx-lg-10">
		<img class="avatar avatar-xxl" src="<?= base_url();?>assets/backend/svg/illustrations/sorry.svg" alt="Image Description">
		<p class="card-text">Terjadi kesalahan saat menampilkan data penilaian anda, Harap hubungi Panitia.</p>
	</div>
</div>
</br>